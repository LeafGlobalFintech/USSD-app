# Leaf-USSD-App
Africas Talking USSD Application written in PHP 

This Application can view a leaf user's account balance and transfer money between leaf clients
